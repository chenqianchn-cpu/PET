# PET 项目 GROMACS 对接结构坐标

这些 .gro 由项目归档的 PPIA–PET-RS 和 IMPDH2–PET-RS 对接构象转换，供结构查看及新模拟的体系准备。
坐标由 Å 转为 nm，按原记录顺序写入，链信息用顺序残基编号衔接。
PPIA 的四个残基存在占有率相同的备选构象，保留 A 构象及共同原子。IMPDH2 保留源结构全部原子。
源结构未定义周期盒，盒向量为 0。开始新模拟前需另行完成力场选择、配体拓扑、水盒和模拟参数准备。

| 文件 | 原子数 | PDB 原子记录数 | 来源（相对 PET 项目） | PDB SHA-256 |
| --- | ---: | ---: | --- | --- |
| PPIA_9GHY_PET-RS_docked.gro | 2523 | 2560 | 原始数据/16.分子动力+分子对接新-PPIA数据用这个/PPIA_9GHY/dock/results/complex_best.pdb | f6ca61283d5e0dfccaa95b850489d701e9ae4ba36c1408883c2c40c61b388240 |
| IMPDH2_6I0M_PET-RS_docked.gro | 10125 | 10125 | 原始数据/11.分子对接/IMPDH2/IMPDH2-6i0m_Conformer3D_COMPOUND_PET_out_5.-6.2.complex.pdb | 9f03519fae05b01c0256c35e35ecf9e44f78a19c6bf0e57c4074e284cf03d0b6 |

## 原 100 ns 模拟复现

本包的结构文件为归档对接构象衍生的坐标。稿件原模拟的参数、拓扑、轨迹及周期盒仍应从原模拟工作目录恢复。
PPIA 的 MM/GBSA 记录提到 md_0_1.tpr、topol.top 和 COM_traj_0.xtc。当前项目归档仅找到相应的分析输出。
取回两种体系的原始 .tpr、.mdp、.top、全部拓扑包含文件和 .xtc 后，可核对本轮结果并整理复现材料。
参考：[GROMACS 文件格式](https://manual.gromacs.org/current/reference-manual/file-formats.html)、[GROMACS 2020.6 gmx dump](https://manual.gromacs.org/2020.6/onlinehelp/gmx-dump.html)。
